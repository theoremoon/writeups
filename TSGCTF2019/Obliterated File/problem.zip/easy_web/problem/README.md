## Development

```
# install crystal lang
$ shards install
$ crystal main.cr
```

## Build

```
$ crystal build main.cr --release
```