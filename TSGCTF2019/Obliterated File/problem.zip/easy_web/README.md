# easy_web

## Problem Statement

The flag is admin's password.
